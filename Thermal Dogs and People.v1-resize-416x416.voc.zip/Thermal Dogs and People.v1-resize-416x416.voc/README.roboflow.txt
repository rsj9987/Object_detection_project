
Thermal Dogs and People - v1 resize-416x416
==============================

This dataset was exported via roboflow.ai on May 25, 2020 at 12:08 PM GMT

It includes 203 images.
Dogs-person are annotated in Pascal VOC format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


